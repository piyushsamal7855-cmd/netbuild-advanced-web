import React from "react";

interface Planet {
  size: number;
  top: string;
  left: string;
  color: string;
  glowColor: string;
  duration: number;
  delay: number;
  orbitDuration: number;
  orbitRadius: number;
  rings?: boolean;
}

const planets: Planet[] = [
  {
    size: 90,
    top: "12%",
    left: "8%",
    color: "radial-gradient(circle at 35% 35%, #7c3aed, #1e1b4b 70%)",
    glowColor: "rgba(124,58,237,0.35)",
    duration: 9,
    delay: 0,
    orbitDuration: 28,
    orbitRadius: 18,
    rings: true,
  },
  {
    size: 54,
    top: "60%",
    left: "5%",
    color: "radial-gradient(circle at 35% 35%, #0ea5e9, #0c4a6e 70%)",
    glowColor: "rgba(14,165,233,0.3)",
    duration: 11,
    delay: 2,
    orbitDuration: 22,
    orbitRadius: 14,
  },
  {
    size: 70,
    top: "8%",
    left: "80%",
    color: "radial-gradient(circle at 35% 35%, #06b6d4, #164e63 70%)",
    glowColor: "rgba(6,182,212,0.3)",
    duration: 13,
    delay: 1,
    orbitDuration: 32,
    orbitRadius: 20,
    rings: true,
  },
  {
    size: 38,
    top: "72%",
    left: "88%",
    color: "radial-gradient(circle at 35% 35%, #818cf8, #1e1b4b 70%)",
    glowColor: "rgba(129,140,248,0.3)",
    duration: 8,
    delay: 3,
    orbitDuration: 18,
    orbitRadius: 12,
  },
  {
    size: 28,
    top: "40%",
    left: "92%",
    color: "radial-gradient(circle at 35% 35%, #a78bfa, #2e1065 70%)",
    glowColor: "rgba(167,139,250,0.25)",
    duration: 7,
    delay: 5,
    orbitDuration: 15,
    orbitRadius: 10,
  },
  {
    size: 20,
    top: "25%",
    left: "55%",
    color: "radial-gradient(circle at 35% 35%, #38bdf8, #075985 70%)",
    glowColor: "rgba(56,189,248,0.2)",
    duration: 6,
    delay: 4,
    orbitDuration: 13,
    orbitRadius: 8,
  },
];

const stars = Array.from({ length: 60 }, (_, i) => ({
  id: i,
  top: `${Math.random() * 100}%`,
  left: `${Math.random() * 100}%`,
  size: Math.random() * 2 + 0.5,
  opacity: Math.random() * 0.6 + 0.1,
  duration: Math.random() * 4 + 2,
  delay: Math.random() * 5,
}));

export default function FloatingPlanets() {
  return (
    <div className="absolute inset-0 w-full h-full pointer-events-none overflow-hidden">
      {stars.map((s) => (
        <div
          key={s.id}
          className="absolute rounded-full bg-white"
          style={{
            top: s.top,
            left: s.left,
            width: s.size,
            height: s.size,
            opacity: s.opacity,
            animation: `star-twinkle ${s.duration}s ease-in-out ${s.delay}s infinite`,
          }}
        />
      ))}

      {planets.map((p, i) => (
        <div
          key={i}
          className="absolute"
          style={{
            top: p.top,
            left: p.left,
            width: p.size,
            height: p.size,
            animation: `planet-orbit ${p.orbitDuration}s ease-in-out ${p.delay}s infinite, planet-float ${p.duration}s ease-in-out ${p.delay}s infinite`,
            "--orbit-r": `${p.orbitRadius}px`,
          } as React.CSSProperties}
        >
          <div
            className="relative w-full h-full rounded-full"
            style={{
              background: p.color,
              boxShadow: `0 0 ${p.size * 0.6}px ${p.size * 0.2}px ${p.glowColor}, inset -${p.size * 0.15}px -${p.size * 0.1}px ${p.size * 0.3}px rgba(0,0,0,0.5)`,
            }}
          >
            <div
              className="absolute rounded-full opacity-20"
              style={{
                top: "15%",
                left: "15%",
                width: "35%",
                height: "25%",
                background: "radial-gradient(ellipse, rgba(255,255,255,0.8), transparent)",
                filter: "blur(2px)",
              }}
            />

            {p.rings && (
              <div
                className="absolute top-1/2 left-1/2 rounded-full border border-white/15"
                style={{
                  width: p.size * 1.7,
                  height: p.size * 0.35,
                  transform: "translate(-50%, -50%) rotateX(72deg)",
                  boxShadow: `0 0 8px ${p.glowColor}`,
                  borderWidth: Math.max(1, p.size * 0.03),
                }}
              />
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
