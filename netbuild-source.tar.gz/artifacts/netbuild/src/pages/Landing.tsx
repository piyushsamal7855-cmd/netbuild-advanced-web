import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Menu, X, ChevronRight, Zap, Calendar, BarChart3, Gauge,
  MessageSquare, Star, ArrowRight, Instagram
} from "lucide-react";
import { 
  SiTailwindcss, SiReact, SiNextdotjs, SiNodedotjs, SiOpenai 
} from "react-icons/si";
import { 
  Accordion, AccordionContent, AccordionItem, AccordionTrigger 
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import ParticleBackground from "@/components/ParticleBackground";
import FloatingPlanets from "@/components/FloatingPlanets";

const navLinks = ["Features", "Our Process", "Pricing", "Portfolio", "FAQ", "Contact"];

const testimonials = [
  {
    quote: "Netbuild completely transformed our digital presence. They didn't just build a website; they engineered an automated system that handles our bookings seamlessly. The aesthetic is incredibly premium.",
    name: "Rahul Verma",
    role: "Founder, TechSpace India",
    stars: 5,
  },
  {
    quote: "The AI chatbot they integrated cut our support load in half overnight. Our site went from generic to genuinely impressive — and Google rankings followed within weeks.",
    name: "Priya Nayak",
    role: "CEO, BrightEdge Solutions",
    stars: 5,
  },
  {
    quote: "I was skeptical about the pricing at first, but the ROI was clear within the first month. The automated lead pipeline alone paid for the entire project.",
    name: "Arjun Mehta",
    role: "Director, Apex Realty",
    stars: 5,
  },
  {
    quote: "Speed, design, and zero headaches post-launch. Netbuild delivered a high-performance site in two weeks that our previous agency couldn't match in six months.",
    name: "Sneha Pattnaik",
    role: "Marketing Head, OrionTech",
    stars: 5,
  },
];

const WHATSAPP_NUMBER = "917855901395";
const createWhatsAppLink = (text?: string) => 
  `https://wa.me/${WHATSAPP_NUMBER}${text ? `?text=${encodeURIComponent(text)}` : ''}`;

export default function Landing() {
  const [isScrolled, setIsScrolled] = React.useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [activeTestimonial, setActiveTestimonial] = React.useState(0);
  const [testimonialDir, setTestimonialDir] = React.useState<"next" | "prev">("next");

  React.useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialDir("next");
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 4500);
    return () => clearInterval(timer);
  }, []);

  const goToTestimonial = (index: number) => {
    setTestimonialDir(index > activeTestimonial ? "next" : "prev");
    setActiveTestimonial(index);
  };

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden selection:bg-primary/30 selection:text-primary-foreground font-sans">
      {/* Dynamic Background Noise/Glows */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[120px] opacity-50 mix-blend-screen" />
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-secondary/10 rounded-full blur-[150px] opacity-40 mix-blend-screen" />
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.03] mix-blend-overlay" />
      </div>

      {/* 1. Sticky Navbar */}
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? "glass-panel border-b border-border/50 py-3" : "bg-transparent py-5"
        }`}
      >
        <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            {/* Logo Fallback */}
            <span className="font-display font-bold text-2xl tracking-tighter text-white drop-shadow-[0_0_10px_rgba(59,130,246,0.8)]">
              Netbuild
            </span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <div className="flex items-center gap-6">
              {navLinks.map((link) => (
                <button 
                  key={link} 
                  onClick={() => scrollTo(link.toLowerCase().replace(' ', '-'))}
                  className="text-sm font-medium text-muted-foreground hover:text-white transition-colors"
                >
                  {link}
                </button>
              ))}
            </div>
            <a href={createWhatsAppLink("Hello Netbuild, I'd like to chat about a project.")} target="_blank" rel="noreferrer">
              <Button className="bg-primary hover:bg-primary/90 text-white animate-pulse-glow border-none rounded-full px-6">
                Let's Chat
              </Button>
            </a>
          </div>

          <button className="md:hidden text-white" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-background/95 backdrop-blur-xl pt-24 px-6 md:hidden"
          >
            <div className="flex flex-col gap-6">
              {navLinks.map((link) => (
                <button 
                  key={link} 
                  onClick={() => scrollTo(link.toLowerCase().replace(' ', '-'))}
                  className="text-2xl font-display font-medium text-left text-white"
                >
                  {link}
                </button>
              ))}
              <a href={createWhatsAppLink("Hello Netbuild, I'd like to chat about a project.")} target="_blank" rel="noreferrer" className="mt-4">
                <Button size="lg" className="w-full bg-primary hover:bg-primary/90 text-white rounded-full">
                  Let's Chat
                </Button>
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="relative z-10">
        {/* 2. Hero Section */}
        <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-4 flex flex-col items-center justify-center min-h-[90vh] text-center overflow-hidden">
          <FloatingPlanets />
          <ParticleBackground />
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass-panel border-primary/30 mb-8 text-xs font-medium text-primary shadow-[0_0_15px_rgba(59,130,246,0.2)]"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            By Piyush Kumar Samal · netbuild.in · Bhubaneswar, Odisha
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-5xl md:text-7xl lg:text-8xl font-display font-bold max-w-5xl leading-[1.1] tracking-tight"
          >
            We Build Next-Gen <br className="hidden md:block"/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
              AI-Powered
            </span> Digital Experiences
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl"
          >
            High-performance automated websites for modern businesses. We fuse cutting-edge design with machine intelligence.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mt-10 flex flex-col sm:flex-row gap-4"
          >
            <Button size="lg" className="rounded-full bg-white text-black hover:bg-gray-200 font-semibold px-8 h-12 text-base shadow-[0_0_20px_rgba(255,255,255,0.3)]" onClick={() => scrollTo('portfolio')}>
              View Work <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="rounded-full glass-panel border-white/10 hover:bg-white/5 font-semibold px-8 h-12 text-base text-white" onClick={() => scrollTo('pricing')}>
              Get a Quote
            </Button>
          </motion.div>
        </section>

        {/* 3. Tech Stack Showcase */}
        <section className="py-10 border-y border-white/5 bg-black/20 backdrop-blur-md">
          <div className="container mx-auto px-4">
            <p className="text-center text-xs font-medium text-muted-foreground uppercase tracking-wider mb-6">Powered by industry-leading technologies</p>
            <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-70">
              <div className="flex items-center gap-2 text-white/80 hover:text-[#06B6D4] transition-colors"><SiTailwindcss className="text-2xl" /><span className="font-display font-semibold">Tailwind CSS</span></div>
              <div className="flex items-center gap-2 text-white/80 hover:text-[#61DAFB] transition-colors"><SiReact className="text-2xl" /><span className="font-display font-semibold">React</span></div>
              <div className="flex items-center gap-2 text-white/80 hover:text-white transition-colors"><SiNextdotjs className="text-2xl" /><span className="font-display font-semibold">Next.js</span></div>
              <div className="flex items-center gap-2 text-white/80 hover:text-[#339933] transition-colors"><SiNodedotjs className="text-2xl" /><span className="font-display font-semibold">Node.js</span></div>
              <div className="flex items-center gap-2 text-white/80 hover:text-[#412991] transition-colors"><SiOpenai className="text-2xl" /><span className="font-display font-semibold">OpenAI / Claude AI</span></div>
            </div>
          </div>
        </section>

        {/* 4. Core Features */}
        <section id="features" className="py-24 md:py-32 relative">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-display font-bold mb-4">Core Capabilities</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">Beyond static pages. We build intelligent, automated engines for growth.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { icon: Zap, title: "AI Feature Integration", desc: "Smart AI chatbots, automated content tools, and robust automated pipelines." },
                { icon: Calendar, title: "Smart Booking Automation", desc: "Instant calendar scheduling, automated reminders, seamless booking flows." },
                { icon: BarChart3, title: "Advanced Analytics Dashboard", desc: "Real-time visitor tracking and metrics natively integrated." },
                { icon: Gauge, title: "High-Performance SEO & Speed", desc: "Ultra-fast loading times, core web vitals optimized out of the box." }
              ].map((feature, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="glass-panel p-8 rounded-2xl group hover:-translate-y-1 transition-all duration-300"
                >
                  <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center mb-6 group-hover:bg-primary/40 transition-colors">
                    <feature.icon className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-display font-bold mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* 5. Our Process */}
        <section id="our-process" className="py-24 md:py-32 bg-black/40 border-y border-white/5">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-20">
              <h2 className="text-3xl md:text-5xl font-display font-bold mb-4">Our Process</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">From concept to deployment, we move with velocity and precision.</p>
            </div>

            <div className="max-w-4xl mx-auto relative">
              <div className="absolute left-[27px] top-0 bottom-0 w-[2px] bg-white/10 hidden md:block"></div>
              
              {[
                { step: "01", title: "Discovery & Strategy", desc: "Analyzing brand goals, user flows, and mapping the technical architecture required for your specific needs." },
                { step: "02", title: "AI-Driven Agile Dev", desc: "Building fast, responsive architectures with clean design modules and integrating smart automations." },
                { step: "03", title: "SEO Sync & Launch", desc: "Performance auditing, responsive tuning, metadata configuration, and live deployment with zero downtime." }
              ].map((item, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.2 }}
                  className="flex flex-col md:flex-row gap-6 mb-12 last:mb-0 relative"
                >
                  <div className="hidden md:flex h-14 w-14 rounded-full bg-background border-2 border-primary items-center justify-center z-10 shrink-0 shadow-[0_0_15px_rgba(59,130,246,0.3)]">
                    <span className="font-display font-bold text-primary">{item.step}</span>
                  </div>
                  <div className="glass-panel p-8 rounded-2xl flex-1 ml-0 md:ml-6">
                    <div className="md:hidden inline-block px-3 py-1 rounded bg-primary/20 text-primary text-sm font-bold mb-4">Step {item.step}</div>
                    <h3 className="text-2xl font-display font-bold mb-3">{item.title}</h3>
                    <p className="text-muted-foreground">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* 6. Pricing */}
        <section id="pricing" className="py-24 md:py-32">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-display font-bold mb-4">Transparent Pricing</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">Invest in a platform that works as hard as you do.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {/* Basic Plan */}
              <div className="glass-panel p-8 rounded-3xl flex flex-col">
                <h3 className="text-xl font-display font-bold mb-2">Basic Plan</h3>
                <div className="flex items-baseline gap-1 mb-6">
                  <span className="text-4xl font-bold">₹15,000</span>
                </div>
                <ul className="flex-1 space-y-4 mb-8">
                  <li className="flex items-center gap-3 text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary" /> Responsive Design</li>
                  <li className="flex items-center gap-3 text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary" /> Standard SEO</li>
                  <li className="flex items-center gap-3 text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary" /> Contact Forms</li>
                  <li className="flex items-center gap-3 text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary" /> 1 Month Support</li>
                </ul>
                <a href={createWhatsAppLink("Hello Netbuild, I want to inquire about the Basic Plan (₹15,000) for my business.")} target="_blank" rel="noreferrer">
                  <Button className="w-full bg-white/10 hover:bg-white/20 text-white rounded-full h-12">Get Started</Button>
                </a>
              </div>

              {/* Standard Plan */}
              <div className="glass-panel p-8 rounded-3xl flex flex-col relative border-primary shadow-[0_0_30px_rgba(59,130,246,0.15)] transform md:-translate-y-4">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-white px-4 py-1 rounded-full text-xs font-bold tracking-wider uppercase animate-pulse-glow">
                  Most Popular
                </div>
                <h3 className="text-xl font-display font-bold mb-2">Standard Plan</h3>
                <div className="flex items-baseline gap-1 mb-6">
                  <span className="text-4xl font-bold text-white">₹25,000</span>
                </div>
                <ul className="flex-1 space-y-4 mb-8">
                  <li className="flex items-center gap-3 text-white/90"><ChevronRight className="h-4 w-4 text-primary" /> Everything in Basic</li>
                  <li className="flex items-center gap-3 text-white/90"><ChevronRight className="h-4 w-4 text-primary" /> AI Features Integration</li>
                  <li className="flex items-center gap-3 text-white/90"><ChevronRight className="h-4 w-4 text-primary" /> Smart Booking Flow</li>
                  <li className="flex items-center gap-3 text-white/90"><ChevronRight className="h-4 w-4 text-primary" /> 3 Months Support</li>
                </ul>
                <a href={createWhatsAppLink("Hello Netbuild, I am interested in the Standard Plan (₹25,000) with AI features.")} target="_blank" rel="noreferrer">
                  <Button className="w-full bg-primary hover:bg-primary/90 text-white rounded-full h-12 shadow-[0_0_15px_rgba(59,130,246,0.4)]">Get Started</Button>
                </a>
              </div>

              {/* Premium Plan */}
              <div className="glass-panel p-8 rounded-3xl flex flex-col">
                <h3 className="text-xl font-display font-bold mb-2">Premium Plan</h3>
                <div className="flex items-baseline gap-1 mb-6">
                  <span className="text-4xl font-bold">₹50,000</span>
                </div>
                <ul className="flex-1 space-y-4 mb-8">
                  <li className="flex items-center gap-3 text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary" /> Everything in Standard</li>
                  <li className="flex items-center gap-3 text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary" /> Custom Automated Solutions</li>
                  <li className="flex items-center gap-3 text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary" /> Advanced Analytics</li>
                  <li className="flex items-center gap-3 text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary" /> 6 Months Priority Support</li>
                </ul>
                <a href={createWhatsAppLink("Hello Netbuild, I want to go with the Premium Plan (₹50,000) for a full-scale automated custom solution.")} target="_blank" rel="noreferrer">
                  <Button className="w-full bg-white/10 hover:bg-white/20 text-white rounded-full h-12">Get Started</Button>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* 7. Portfolio */}
        <section id="portfolio" className="py-24 md:py-32 bg-black/40 border-y border-white/5">
          <div className="container mx-auto px-4 md:px-6">
            <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-4">
              <div>
                <h2 className="text-3xl md:text-5xl font-display font-bold mb-4">Selected Work</h2>
                <p className="text-muted-foreground max-w-xl">A glimpse into the digital experiences we've engineered.</p>
              </div>
              <Button variant="outline" className="rounded-full glass-panel border-white/10 text-white" onClick={() => scrollTo('contact')}>
                Start Your Project
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map((item) => (
                <div key={item} className="group relative aspect-[4/3] rounded-2xl overflow-hidden glass-panel">
                  {/* <!-- INSERT CLIENT WEBSITE SCREENSHOT HERE --> */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full border border-white/20 flex items-center justify-center animate-pulse">
                      <Zap className="h-6 w-6 text-white/50" />
                    </div>
                  </div>
                  
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-8 backdrop-blur-sm">
                    <span className="text-primary font-medium text-sm mb-2">Client Project</span>
                    <h3 className="text-2xl font-display font-bold text-white translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                      Project Alpha {item}
                    </h3>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 8. Testimonials & Social Proof */}
        <section className="py-24 md:py-32 overflow-hidden">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-14">
              <span className="text-xs font-semibold uppercase tracking-widest text-primary mb-3 block">Client Stories</span>
              <h2 className="text-3xl md:text-5xl font-display font-bold">What Our Clients Say</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              {/* Sliding review */}
              <div className="relative min-h-[280px]">
                <AnimatePresence mode="wait" custom={testimonialDir}>
                  <motion.div
                    key={activeTestimonial}
                    custom={testimonialDir}
                    variants={{
                      enter: (dir: string) => ({ x: dir === "next" ? 80 : -80, opacity: 0 }),
                      center: { x: 0, opacity: 1 },
                      exit: (dir: string) => ({ x: dir === "next" ? -80 : 80, opacity: 0 }),
                    }}
                    initial="enter"
                    animate="center"
                    exit="exit"
                    transition={{ duration: 0.45, ease: "easeInOut" }}
                    className="absolute inset-0"
                  >
                    <div className="glass-panel rounded-3xl p-8 h-full flex flex-col justify-between border border-white/5 shadow-[0_0_40px_rgba(99,102,241,0.08)]">
                      <div>
                        <div className="flex gap-1 mb-6">
                          {Array.from({ length: testimonials[activeTestimonial].stars }).map((_, i) => (
                            <Star key={i} className="h-4 w-4 text-primary fill-primary" />
                          ))}
                        </div>
                        <blockquote className="text-xl md:text-2xl font-display font-medium leading-snug text-foreground/90">
                          "{testimonials[activeTestimonial].quote}"
                        </blockquote>
                      </div>
                      <div className="mt-8 flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold text-sm shrink-0">
                          {testimonials[activeTestimonial].name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-sm">{testimonials[activeTestimonial].name}</div>
                          <div className="text-muted-foreground text-xs">{testimonials[activeTestimonial].role}</div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                </AnimatePresence>

                {/* Dot indicators */}
                <div className="absolute -bottom-10 left-0 flex gap-2">
                  {testimonials.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => goToTestimonial(i)}
                      data-testid={`testimonial-dot-${i}`}
                      className={`rounded-full transition-all duration-300 ${
                        i === activeTestimonial
                          ? "w-6 h-2 bg-primary"
                          : "w-2 h-2 bg-white/20 hover:bg-white/40"
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Instagram card */}
              <div className="glass-panel p-6 rounded-3xl max-w-md mx-auto w-full flex flex-col gap-4 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-pink-500/20 rounded-full blur-[50px]" />
                <div className="flex items-center justify-between mb-4 relative z-10">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-pink-500 p-[2px]">
                      <div className="bg-background w-full h-full rounded-full flex items-center justify-center text-xs font-bold">NB</div>
                    </div>
                    <div>
                      <div className="font-bold text-sm leading-none mb-1">netbuild.in</div>
                      <div className="text-xs text-muted-foreground">Odisha, India</div>
                    </div>
                  </div>
                  <Instagram className="text-muted-foreground" />
                </div>
                <div className="aspect-square bg-white/5 rounded-xl flex items-center justify-center border border-white/5 relative z-10">
                  <span className="text-muted-foreground text-sm">Instagram Post Preview</span>
                </div>
                <a href="https://instagram.com" target="_blank" rel="noreferrer" className="relative z-10">
                  <Button className="w-full bg-white/10 hover:bg-white/20 text-white rounded-xl">Follow @netbuild.in</Button>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* 9. FAQ */}
        <section id="faq" className="py-24 md:py-32 bg-black/40 border-y border-white/5">
          <div className="container mx-auto px-4 md:px-6 max-w-3xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-display font-bold mb-4">Frequently Asked Questions</h2>
            </div>

            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1" className="border-white/10">
                <AccordionTrigger className="text-left font-display font-medium text-lg hover:text-primary transition-colors">
                  What makes Netbuild different from traditional web agencies?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-base leading-relaxed">
                  We don't just build static sites; we build AI-powered, fully automated digital environments featuring custom smart booking, active lead automation, and optimized modern frameworks.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2" className="border-white/10">
                <AccordionTrigger className="text-left font-display font-medium text-lg hover:text-primary transition-colors">
                  Do you provide custom pricing if my requirements are unique?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-base leading-relaxed">
                  Yes, absolutely! While our pricing tiers cover fundamental scalable requirements, we coordinate custom configurations for specialized corporate apps or complex technical systems.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3" className="border-white/10">
                <AccordionTrigger className="text-left font-display font-medium text-lg hover:text-primary transition-colors">
                  Will my website be mobile-friendly and SEO optimized?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-base leading-relaxed">
                  Yes, every website we build is 100% responsive across all devices and comes with built-in SEO best practices and fast loading speeds.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </section>

        {/* 10. Contact & Footer */}
        <section id="contact" className="pt-24 pb-12 relative overflow-hidden">
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full max-w-3xl h-64 bg-primary/20 rounded-t-full blur-[100px] pointer-events-none -z-10"></div>
          
          <div className="container mx-auto px-4 md:px-6 text-center max-w-2xl mb-24">
            <h2 className="text-4xl md:text-6xl font-display font-bold mb-6">Ready to Build the Future?</h2>
            <p className="text-xl text-muted-foreground mb-10">
              Let's craft an AI-powered digital experience that puts your business lightyears ahead.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a href={createWhatsAppLink("Hello Netbuild, I'm ready to start a project.")} target="_blank" rel="noreferrer">
                <Button size="lg" className="rounded-full bg-primary hover:bg-primary/90 text-white font-semibold px-8 h-14 text-lg shadow-[0_0_20px_rgba(59,130,246,0.4)] animate-pulse-glow">
                  <MessageSquare className="mr-2 h-5 w-5" /> Connect via WhatsApp
                </Button>
              </a>
            </div>
            
            <div className="mt-12 flex flex-col md:flex-row items-center justify-center gap-6 text-muted-foreground">
              <a href="mailto:netbuildofficial@gmail.com" className="hover:text-white transition-colors">netbuildofficial@gmail.com</a>
              <span className="hidden md:inline">•</span>
              <a href={`tel:+${WHATSAPP_NUMBER}`} className="hover:text-white transition-colors">+91 7855901395</a>
            </div>
          </div>

          <footer className="container mx-auto px-4 border-t border-white/5 pt-8 mt-12 flex flex-col md:flex-row items-center justify-between text-sm text-muted-foreground">
            <div>© 2026 Netbuild. All rights reserved.</div>
            <div className="mt-4 md:mt-0">Founded by Piyush Kumar Samal. Bhubaneswar, Odisha.</div>
          </footer>
        </section>
      </main>

      {/* 11. Floating WhatsApp Widget */}
      <a 
        href={createWhatsAppLink("Hello Netbuild")} 
        target="_blank" 
        rel="noreferrer"
        className="fixed bottom-6 right-6 z-50 group flex items-center"
      >
        <div className="absolute right-full mr-4 bg-white text-black px-3 py-1.5 rounded-lg text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-lg pointer-events-none">
          Chat with us
        </div>
        <div className="bg-[#25D366] text-white p-4 rounded-full shadow-[0_0_20px_rgba(37,211,102,0.4)] hover:scale-110 transition-transform cursor-pointer flex items-center justify-center relative">
          <span className="absolute inset-0 rounded-full border-2 border-[#25D366] animate-ping opacity-75"></span>
          <MessageSquare className="h-6 w-6 relative z-10" />
        </div>
      </a>
    </div>
  );
}
